import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class Order implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int no;
	private String name;
	private String phone;
	private ArrayList<MainMenu> menu;
	private String date;
	private int total_price=0;
	private boolean payment = false;
	
	private Date d;
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	Order(int no,String name, String phone, ArrayList<MainMenu> menu){
		d = new Date();
		this.no =no;
		this.name = name;
		this.phone = phone;
		this.menu = menu;
		
		for(int i=0; i<menu.size(); i++) {
			total_price += menu.get(i).getMenu_Price();
		}
		
		this.date = sdf.format(d);
	}
	public int getNo() {
		return this.no;
	}
	public String getName() {
		return this.name;
	}
	public String getPhone() {
		return this.phone;
	}
	public ArrayList<MainMenu> getMenu() {
		return this.menu;
	}
	public boolean getPayment(){
		return this.payment;
	}
	public int getTotalPrice(){
		return this.total_price;
	}
	public String getDate(){
		return this.date;
	}
	public void setPayment(boolean payment){
		this.payment = payment;
	}

}
