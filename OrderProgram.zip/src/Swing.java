import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;


public class Swing extends JFrame implements ActionListener{
	
	private MenuBar bar;
	private Menu m1;
	private MenuItem m1_1, m1_2, m1_3;
	private JButton a,b,enl,d,f,order_ok,modify,enroll,delete,left,right,bottom_middle_center_right,cal,left2,right2,bottom_right_center_right, bottom_middle_head_right;
	private JPanel background, table;
	private JTextField total;
	private JTable two, aocnfTable, rhrorTable, apsbTable;
	private JTextField input_name, input_phone;
	private JTextField bottom_middle_center_center; // 고객 검색 텍스트필드
	private JTextField bottom_right_center_center; // 메뉴 검색 텍스트필드
	private CardLayout cardlayout;
	private JButton[] table_array = new JButton[14];
	private JButton[] order_array = new JButton[12];
	private JComboBox<String> date_combobox;
	private ArrayList<Customer> customerList = new ArrayList<>();
	private ArrayList<Order> OrderList = new ArrayList<>();
	private ArrayList<MainMenu> jumun; //주문내역 MainMenu에 저장
	private ArrayList<MainMenu> Pig = new ArrayList<>();
	private ArrayList<MainMenu> Pasta = new ArrayList<>();
	private ArrayList<MainMenu> Drink = new ArrayList<>();
	private int table_no=1;

	private int flag = 0;
	private int tot=0;
	
	final private String colname[] = {"메뉴이름","가격"};  //주문화면tablehead
	final private String aocnfcol[] = {"날짜", "고객명", "총계"}; //매출하면tablehead
	final private String rhrorcol[] = {"날짜", "메뉴", "가격"}; //고객검색tablehead
	final private String apsbcol[] = {"날짜", "고객명"}; //메뉴검색tablehead
	
	private DefaultTableModel wnans;
	private DefaultTableModel aocnf;
	private DefaultTableModel rhror;
	private DefaultTableModel apsb;
	
	public Swing(){
		setTitle("주문관리시스템");
		
		CustomerRW crw = new CustomerRW("customerlist.dat"); //고객 정보 리스트 불러움
        customerList = crw.readFile();
        
		Pig.add(new MainMenu("왕돈까스", 8800));  //menu등록
		Pig.add(new MainMenu("로스까스", 8800));
		Pig.add(new MainMenu("생선까스", 9300));
		Pig.add(new MainMenu("돈까스정식", 9800));
		Pig.add(new MainMenu("크림돈까스", 11000));
		Pig.add(new MainMenu("고구마롤", 9300));
		Pig.add(new MainMenu("포테이토롤", 9300));
		Pig.add(new MainMenu("치즈롤", 9300));
		
		Pasta.add(new MainMenu("해물볶음우동", 7500));
		Pasta.add(new MainMenu("로제파스타", 9800));
		Pasta.add(new MainMenu("까르보나라", 9300));
		Pasta.add(new MainMenu("해물크림", 9800));
		Pasta.add(new MainMenu("토마토치즈", 9800));
		Pasta.add(new MainMenu("우동", 5000));

		Drink.add(new MainMenu("콜라",2000));
		Drink.add(new MainMenu("사이다",2000));
		Drink.add(new MainMenu("마운틴듀",2000));
		Drink.add(new MainMenu("카스",4000));
		Drink.add(new MainMenu("하이트",4000));
		Drink.add(new MainMenu("클라우드",5000));
		Drink.add(new MainMenu("호가든",7000));
		Drink.add(new MainMenu("하이네켄",7000));
		Drink.add(new MainMenu("버드와이저",7000));
		
		
		LineBorder border = new LineBorder(Color.BLACK,1);
		LineBorder border2 = new LineBorder(Color.BLACK,2);

		bar = new MenuBar();
		m1 = new Menu("File");
		m1_1 = new MenuItem("Open");
		m1_1.addActionListener(this);
		m1_2 = new MenuItem("Save");
		m1_2.addActionListener(this);
		m1_3 = new MenuItem("Exit");
		m1_3.addActionListener(this);
		setMenuBar(bar);
		
		bar.add(m1);
		m1.add(m1_1);
		m1.add(m1_2);
		m1.add(m1_3);
		
		JPanel head = new JPanel();
		JLabel title = new JLabel("  한양돈까스  ");
		title.setFont(new Font("고딕",Font.BOLD,50));
		setLayout(new BorderLayout());
		title.setBorder(border);
		head.setBackground(Color.WHITE);
		head.add(title);
		add(head,"North");
	
		background = new JPanel();
		cardlayout = new CardLayout();
		background.setLayout(cardlayout);
				
		JPanel choose = new JPanel();       //주문과 관리를 선택하는 페이지(카드)
		choose.setBackground(Color.WHITE);
		choose.setLayout(new GridLayout(1,2,50,50));
		choose.setBorder(new EmptyBorder(80, 30,80 , 30));
		
	
		a = new JButton("주문");
		a.setFont(new Font("고딕",Font.BOLD,40));
		//a.setBackground(Color.ORANGE);
		a.addActionListener(this);
		b = new JButton("관리");
		//b.setBackground(Color.ORANGE);
		b.setFont(new Font("고딕",Font.BOLD,40));
		b.addActionListener(this);
		
		background.add("choose", choose);
		
		choose.add(a);
		choose.add(b);
		
		JPanel control = new JPanel();      //관리를 관리하는 페이지(카드)
		control.setBackground(Color.WHITE);
		control.setLayout(new BorderLayout());
		JPanel top = new JPanel();
		top.setBackground(Color.WHITE);
		control.add(top,"North");
		f = new JButton("뒤로");
		f.addActionListener(this);
		top.add(f);
		
		
		JPanel bottom = new JPanel();
		bottom.setLayout(new GridLayout(1,3));
		JPanel bottom_left = new JPanel();
		bottom_left.setBackground(Color.WHITE);
		bottom_left.setBorder(border2);
		bottom_left.setLayout(null);
		JLabel bottom_left_head = new JLabel("매출현황");
		bottom_left_head.setBounds(10,0,80,30);
		bottom_left.add(bottom_left_head);
		JLabel bottom_left_middle = new JLabel("기간선택");
		bottom_left_middle.setBounds(10,30,80,30);
		bottom_left.add(bottom_left_middle);
		date_combobox = new JComboBox();
		date_combobox.addItemListener(new ItemListener() { //기간선택
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub 
				String selectedDate = e.getItem().toString();
				int rowCount = aocnf.getRowCount();
				for(int i=rowCount-1; i>=0; i--)
					aocnf.removeRow(i);
				for(int i=0; i<OrderList.size(); i++){
					if(selectedDate.equals(OrderList.get(i).getDate()) && OrderList.get(i).getPayment() == true){
						String arr[] = {OrderList.get(i).getDate(), OrderList.get(i).getName(), String.valueOf(OrderList.get(i).getTotalPrice())};
						aocnf.addRow(arr);
					}
				}
			}
		});;
		date_combobox.setBounds(90,30,100,30);
		bottom_left.add(date_combobox);
		aocnf = new DefaultTableModel(aocnfcol, 0);
		aocnfTable = new JTable(aocnf);
		JScrollPane aocnfScroll = new JScrollPane(aocnfTable);
		aocnfScroll.setBorder(border);
		aocnfScroll.setBounds(10,60,240,260);
		bottom_left.add(aocnfScroll);
		bottom.add(bottom_left);

		
		JPanel bottom_middle = new JPanel();
		bottom_middle.setBackground(Color.WHITE);
		bottom_middle.setBorder(border2);
		bottom_middle.setLayout(null);
		JLabel bottom_middle_head = new JLabel("고객검색");
		bottom_middle_head.setBounds(10,0,80,30);
		bottom_middle.add(bottom_middle_head);
		JLabel bottom_middle_center_left = new JLabel("고객이름");
		bottom_middle_center_left.setBounds(10,30,70,30);
		bottom_middle.add(bottom_middle_center_left);
		bottom_middle_center_center = new JTextField();
		bottom_middle_center_center.setBounds(80,30,90,30);
		bottom_middle.add(bottom_middle_center_center);
		bottom_middle_center_right = new JButton("검색");
		bottom_middle_center_right.addActionListener(this);
		bottom_middle_center_right.setBounds(180,34,70,25);
		bottom_middle.add(bottom_middle_center_right);
		bottom_middle_head_right = new JButton("변경");
		bottom_middle_head_right.addActionListener(this);
		bottom_middle_head_right.setBounds(180,4,70,25);
		bottom_middle.add(bottom_middle_head_right);
		rhror = new DefaultTableModel(rhrorcol, 0);
		rhrorTable = new JTable(rhror);
		JScrollPane rhrorScroll = new JScrollPane(rhrorTable);
		rhrorScroll.setBorder(border);
		rhrorScroll.setBounds(10,60,240,260);
		bottom_middle.add(rhrorScroll);
		bottom.add(bottom_middle);

		
		JPanel bottom_right = new JPanel();
		bottom_right.setBackground(Color.WHITE);
		bottom_right.setBorder(border2);
		bottom_right.setLayout(null);
		JLabel bottom_right_head = new JLabel("메뉴검색");
		bottom_right_head.setBounds(10,0,80,30);
		bottom_right.add(bottom_right_head);
		JLabel bottom_right_center_left = new JLabel("메뉴이름");
		bottom_right_center_left.setBounds(10,30,70,30);
		bottom_right.add(bottom_right_center_left);
		bottom_right_center_center = new JTextField();
		bottom_right_center_center.setBounds(80,30,90,30);
		bottom_right.add(bottom_right_center_center);
		bottom_right_center_right = new JButton("검색");
		bottom_right_center_right.addActionListener(this);
		bottom_right_center_right.setBounds(180,34,70,25);
		bottom_right.add(bottom_right_center_right);
		apsb = new DefaultTableModel(apsbcol, 0);
		apsbTable = new JTable(apsb);
		JScrollPane apsbScroll = new JScrollPane(apsbTable);
		apsbScroll.setBorder(border);
		apsbScroll.setBounds(10,60,240,260);
		bottom_right.add(apsbScroll);
		bottom.add(bottom_right);

		
		control.add(bottom,"Center");

		background.add("control", control); //관리
		
		
		//주문
		JPanel order = new JPanel();
		order.setLayout(new BorderLayout());
		JPanel back = new JPanel();
		order.add(back,"North");
		back.setBackground(Color.WHITE);
		JLabel space = new JLabel("                                                                                                                                                              ");
		enl = new JButton("뒤로");
		
		back.add(enl);
		back.add(space);
		
		enl.addActionListener(this);
		
		
		table = new JPanel();        //table button 달려있는 패널
		table.setBackground(Color.WHITE);

		
		table.setLayout(new GridLayout(2,7,10,10));
		table.setBorder(new EmptyBorder(20, 20,20 ,20 ));
		
		for(int i=0;i<14;i++){
			table_array[i] = new JButton(String.valueOf(i+1));
			table.add(table_array[i]);
			table_array[i].setBorder(border2);
			table_array[i].setBackground(Color.LIGHT_GRAY);
			table_array[i].addActionListener(this);
		}
		order.add(table,"Center");
		background.add("order", order);

		
		add(background,"Center");
		cardlayout.show(background,"choose");
		
		JPanel input = new JPanel();    //고객주문화면
		background.add("input",input);
		input.setLayout(null);
		JPanel back2 = new JPanel();
		back2.setBounds(0,0,780,30);
		back2.setLayout(null);
		d = new JButton("뒤로");
		d.setBounds(10,0,60,30);
		total = new JTextField();
		total.setBounds(600,0,110,30);
		total.setBorder(border);
		total.setFont(new Font("고딕",Font.BOLD,20));
		
		cal = new JButton("결제");
		cal.addActionListener(this);
		cal.setBounds(720,0,60,30);
		total.setText("       "+tot + " 원");
		
		back2.setBackground(Color.WHITE);
		back2.add(d);
		d.addActionListener(this);
		back2.add(total);
		back2.add(cal);
		input.add(back2);

		JPanel order2 = new JPanel();
		order2.setLayout(new GridLayout(1,2));
		order2.setBounds(0,30,780,340);
		input.add(order2);
		JPanel w = new JPanel();
		w.setBackground(Color.WHITE);
		w.setLayout(new GridLayout(4,4,1,1));
		w.setBorder(new EmptyBorder(10, 10,10 ,10));
		for(int i=0;i<12;i++){
			order_array[i] = new JButton();  //돈까스메뉴 
			if(i < Pig.size()){
				order_array[i].setText(Pig.get(i).getMenu_Name());
			}
			order_array[i].addActionListener(this);
			w.add(order_array[i]);
			order_array[i].setBorder(border2);
		}
		left = new JButton("◀");
		left.addActionListener(this);
		JLabel mu1 = new JLabel(" ");
		JLabel mu2 = new JLabel(" ");
		right = new JButton("▶");
		right.addActionListener(this);
		w.add(left);
		w.add(mu1);
		w.add(mu2);
		w.add(right);
		
		
		JPanel e = new JPanel();   
		e.setLayout(null);
		e.setBackground(Color.WHITE);
		
		JLabel label1 = new JLabel("주문현황");
		label1.setBounds(0, 0, 70, 30);
		e.add(label1);
		
		wnans = new DefaultTableModel(colname,0);
		two= new JTable(wnans);
		two.setFont(new Font("고딕",Font.PLAIN,15));
		JScrollPane js = new JScrollPane(two);
		js.setBounds(0, 30, 390, 180);
		js.setBorder(border);
		e.add(js);
		
		JLabel name = new JLabel("고객명");
		name.setBounds(50,210,80,30);
		e.add(name);
		
		input_name = new JTextField();
		input_name.setBounds(130,210,130,30);
		e.add(input_name);
		
		enroll = new JButton("고객등록");
		enroll.addActionListener(this);
		enroll.setBounds(260,210,130,60);
		e.add(enroll);
		
		JLabel phone = new JLabel("PHONE");
		phone.setBounds(50,240,80,30);
		e.add(phone);
		
		input_phone = new JTextField();
		input_phone.setEditable(false);
		input_phone.setBorder(border);
		input_phone.setBounds(130,240,130,30);
		e.add(input_phone);
				
		modify = new JButton("메뉴취소");
		modify.setBounds(0,270,130,60);
		modify.addActionListener(this);
		e.add(modify);
		
		delete = new JButton("전체삭제");
		delete.setBounds(130,270,130,60);
		delete.addActionListener(this);
		e.add(delete);
		
		order_ok = new JButton("주문");
		order_ok.setBounds(260,270,130,60);
		order_ok.addActionListener(this);
		e.add(order_ok);

		
		order2.add(w);
		order2.add(e);

		setSize(800,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true); //주문
		
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==a){ //주문버튼
			cardlayout.show(background,"order");
		}else if(e.getSource()==enl){ //첫번째뒤로버튼
			cardlayout.show(background,"choose");
		}else if(e.getSource()==d){ //두번째뒤로버튼
			cardlayout.show(background, "order");
			input_name.setText("");
			input_phone.setText("");
			tot=0;
			int rowCount = wnans.getRowCount();
			for(int i=rowCount-1; i>=0; i--)
				wnans.removeRow(i);
			total.setText("       "+tot + " 원");
		}else if(e.getSource()==b){ //관리버튼
			cardlayout.show(background, "control");
			String date = null;
			date_combobox.removeAllItems();
			for(int i=0; i<OrderList.size(); i++){
				if(OrderList.get(i).getPayment() == true) {
					int tmp=0;
					date = OrderList.get(i).getDate(); //OrderList에서 계산된 주문의 날짜를 가져옴
					if(date_combobox.getItemCount() == 0) {
						date_combobox.addItem(date);
					}
					else {
						for(int j=0; j<date_combobox.getItemCount(); j++) {
							if(date.equals(date_combobox.getItemAt(j))) {
								tmp++;
							}
						}
						if(tmp==0)
							date_combobox.addItem(date); //고객 페이지의 기간 콤보박스에 아이템을 추가
					}
				}
			}
		}else if(e.getSource()==f){ //관리에 있는 뒤로버튼
			cardlayout.show(background, "choose");
			
		}else if(e.getSource()==enroll){ //고객등록
			new CustomerEnroll("고객 등록", "등록", "취소");
		}else if(e.getSource()==modify){ //메뉴취소 (선택)
			int rowNum = two.getSelectedRow();
			if (rowNum > -1) {
				tot = tot - jumun.get(rowNum).getMenu_Price();
				wnans.removeRow(rowNum);
				jumun.remove(rowNum);
				total.setText(" "+ tot + " 원");
			}
		}else if(e.getSource()==delete){   //table(주문목록) 전체삭제, jumun현황 list 삭제
			tot=0;
			int rowCount = wnans.getRowCount();
			for(int i=rowCount-1; i>=0; i--)
				wnans.removeRow(i);
			jumun.clear();
			total.setText("       "+tot + " 원");
		}else if(e.getSource()==cal){  //계산하면 테이블, 주문 내역 모두 초기화
			for(int i=0; i<OrderList.size(); i++) {
				if (OrderList.get(i).getNo() == table_no && OrderList.get(i).getPayment() == false) {
					OrderList.get(i).setPayment(true);
				}
			}
			table_array[table_no-1].setBackground(Color.LIGHT_GRAY);
			input_name.setText("");
			input_phone.setText("");
			tot=0;
			int rowCount = wnans.getRowCount();
			for(int i=rowCount-1; i>=0; i--)
				wnans.removeRow(i);
			total.setText("       "+tot + " 원");
			JOptionPane.showMessageDialog(null, "결제 완료되었습니다.");
			cardlayout.show(background, "order");
		}
		else if(e.getSource()==order_ok){       //고객명 입력시 에러처리, OrderList에 입력
			String bringphone =""; //전화번호가져오기
			if(input_name.getText().equals("")){
				JOptionPane.showMessageDialog(null, "고객명을 입력하세요.");
			}
			else{
				int x=0;
				for(int i=0;i<customerList.size();i++ ){
					if(input_name.getText().equals(customerList.get(i).getName())){
						x++;
						bringphone = customerList.get(i).getPhone();
					}
				}
				if(x==0){
					JOptionPane.showMessageDialog(null, "등록되지 않은 고객입니다");
				}else{
					input_phone.setText(bringphone);
					ArrayList<MainMenu> tmp = new ArrayList<>();
					for(int i=0; i<jumun.size(); i++){
						tmp.add(jumun.get(i));
					}
					OrderList.add(new Order(table_no, input_name.getText(), input_phone.getText(), tmp));
					JOptionPane.showMessageDialog(null, "주문 되었습니다");

					cardlayout.show(background,"order");
					table_array[table_no-1].setBackground(Color.YELLOW);
					input_name.setText("");
					input_phone.setText("");
					tot=0;
					int rowCount = wnans.getRowCount();
					for(int i=rowCount-1; i>=0; i--)
						wnans.removeRow(i);
					jumun.clear(); //주문리스트에 있는 주문목록 새로 초기화
					total.setText("       "+tot + " 원");
				}
			}
		}else if(e.getSource()==right){  //▶버튼
			flag=(flag+1)%3;
			if(flag==1){
				for(int i=0;i<12;i++){
					order_array[i].setText("");
					if(i < Pasta.size()){
						order_array[i].setText(Pasta.get(i).getMenu_Name());
					}
				}
			}else if(flag==2){
				for(int i=0;i<12;i++){
					order_array[i].setText("");
					if(i < Drink.size()){
						order_array[i].setText(Drink.get(i).getMenu_Name());
					}
				}
			}else if(flag==0){
				for(int i=0;i<12;i++){
					order_array[i].setText("");
					if(i < Pig.size()){
						order_array[i].setText(Pig.get(i).getMenu_Name());
					}
				}
			}
		}else if(e.getSource()==left){  //◀버튼
			if(flag==1){
				for(int i=0;i<12;i++){
					order_array[i].setText("");
					if(i < Pig.size()){
						order_array[i].setText(Pig.get(i).getMenu_Name());
					}
				}
				flag=0;
			}else if(flag==2){
				for(int i=0;i<12;i++){
					order_array[i].setText("");
					if(i < Pasta.size()){
						order_array[i].setText(Pasta.get(i).getMenu_Name());
					}
				}
				flag=1;
			}else if(flag==0){
				for(int i=0;i<12;i++){
					order_array[i].setText("");
					if(i < Drink.size()){
						order_array[i].setText(Drink.get(i).getMenu_Name());
					}
				}
				flag=2;
			}
		}
		else if(e.getSource()==m1_1){   //주문데이터 오픈
			JFileChooser fileChooser = new JFileChooser();
	         int result = fileChooser.showOpenDialog(null);
	           if( result == JFileChooser.APPROVE_OPTION)
	           {
	               File file = fileChooser.getSelectedFile();
	               String fileName = file.getName();
	               OrderRW orw = new OrderRW(fileName);
	               OrderList = orw.readFile();
	           }
		}else if(e.getSource()==m1_2){  //주문데이터 저장
			OrderRW orw = new OrderRW(OrderList);
			orw.saveFile();
		}else if(e.getSource()==m1_3){ //종료
			System.exit(0);
		}else if(e.getSource()==bottom_middle_head_right) { // 고객정보 변경 버튼
			int tmp=0;
			String name = bottom_middle_center_center.getText().toString();
			for(int i=0; i<customerList.size(); i++) {
				if(name.equals(customerList.get(i).getName())){
					tmp++;
					new CustomerModify();
					break;
				}
			}
			if(tmp==0)
				JOptionPane.showMessageDialog(null, "해당 고객이 존재하지 않습니다.");
		}else if(e.getSource()==bottom_middle_center_right) { // 고객검색 버튼
			int rowCount = rhror.getRowCount();
			for(int i=rowCount-1; i>=0; i--)
				rhror.removeRow(i);
			String name = bottom_middle_center_center.getText().toString();
			for(int i=0; i<OrderList.size(); i++) {
				if (name.equals(OrderList.get(i).getName()) && OrderList.get(i).getPayment() == true) {
					ArrayList<MainMenu> tmp = OrderList.get(i).getMenu();
					for(int j=0; j<tmp.size(); j++) {
						String arr[] = {OrderList.get(i).getDate(), tmp.get(j).getMenu_Name(), String.valueOf(tmp.get(j).getMenu_Price())};
						rhror.addRow(arr);
					}
				}
			}
		}else if(e.getSource()==bottom_right_center_right) {  //메뉴검색
			int rowCount = apsb.getRowCount();
			for(int i=rowCount-1; i>=0; i--)
				apsb.removeRow(i);
			String name = bottom_right_center_center.getText().toString();
			ArrayList<MainMenu> tmp;
			for(int i=0; i<OrderList.size(); i++) {
				if (OrderList.get(i).getPayment() == true) {
					tmp = OrderList.get(i).getMenu();
					for(int j=0; j<tmp.size(); j++) {
						if(name.equals(tmp.get(j).getMenu_Name())) {
							String arr[] = {OrderList.get(i).getDate(), OrderList.get(i).getName()};
							apsb.addRow(arr);
						}
					}
				}
			}
		}
		for(int i=0;i<14;i++){
			
			if(e.getSource() == table_array[i]){  //table버튼 
				table_no = i+1;
				cardlayout.show(background, "input");
				jumun = new ArrayList<>();

				for(int j=0; j<OrderList.size(); j++) {   //주문정보 가져오기
					if(OrderList.get(j).getNo()==i+1 && OrderList.get(j).getPayment()==false){
						jumun = OrderList.get(j).getMenu();
						input_name.setText(OrderList.get(j).getName());
						input_phone.setText(OrderList.get(j).getPhone());
						tot = OrderList.get(j).getTotalPrice();
						total.setText(" "+ tot + " 원");
						for(int k=0; k<jumun.size(); k++){
							String arr[] = {jumun.get(k).getMenu_Name(), String.valueOf(jumun.get(k).getMenu_Price())};
							wnans.addRow(arr);
						}	
					}
				}
			}
		}
		for(int i=0;i<12;i++){  
			if(e.getSource() == order_array[i]){   //주문하기
				if(i< Pig.size()&&order_array[i].getText()==Pig.get(i).getMenu_Name()){
					jumun.add(new MainMenu(order_array[i].getText(),Pig.get(i).getMenu_Price()));
					String arr[] = {order_array[i].getText(), String.valueOf(Pig.get(i).getMenu_Price())};
					wnans.addRow(arr);
					tot = tot + Pig.get(i).getMenu_Price();
					total.setText(" "+ tot + " 원");
				}else if(i <Pasta.size() && order_array[i].getText()==Pasta.get(i).getMenu_Name()){
					jumun.add(new MainMenu(order_array[i].getText(),Pasta.get(i).getMenu_Price()));
					String arr[] = {order_array[i].getText(), String.valueOf(Pasta.get(i).getMenu_Price())};
					wnans.addRow(arr);
					tot = tot + Pasta.get(i).getMenu_Price();
					total.setText(" "+ tot + " 원");
				}else if(i < Drink.size() && order_array[i].getText()==Drink.get(i).getMenu_Name()){
					jumun.add(new MainMenu(order_array[i].getText(),Drink.get(i).getMenu_Price()));
					String arr[] = {order_array[i].getText(), String.valueOf(Drink.get(i).getMenu_Price())};
					wnans.addRow(arr);
					tot = tot + Drink.get(i).getMenu_Price();
					total.setText(" "+ tot + " 원");
				}
			}
		}
	}

	class CustomerEnroll extends JFrame implements ActionListener{ //고객등록 화면
		private JPanel panel;
		private JLabel nameLabel;
		private JLabel birthLabel;
		private JLabel phoneLabel;
		JTextField nameInput;
		JTextField birthInput;
		JTextField phoneInput;
		JButton joinButton;
		JButton cancelButton;
		
		public CustomerEnroll(String title, String button1, String button2) {
			setTitle(title);
			
			panel = new JPanel();
			nameLabel = new JLabel("고객명");
			birthLabel = new JLabel("생일");
			phoneLabel = new JLabel("전화번호");
			nameInput = new JTextField();
			birthInput = new JTextField();
			phoneInput = new JTextField();
			joinButton = new JButton(button1);
			cancelButton = new JButton(button2);
			
			panel.setLayout(null);
			nameLabel.setBounds(20,10,100,30);
			nameInput.setBounds(120,10,100,30);
			birthLabel.setBounds(20,70,100,30);
			birthInput.setBounds(120,70,100,30);
			phoneLabel.setBounds(20,130,100,30);
			phoneInput.setBounds(120,130,100,30);
			joinButton.setBounds(10,190,100,35);
			cancelButton.setBounds(120,190,100,35);
			
			joinButton.addActionListener(this);
			cancelButton.addActionListener(this);
			
			panel.add(nameLabel);
			panel.add(nameInput);
			panel.add(birthLabel);
			panel.add(birthInput);
			panel.add(phoneLabel);
			panel.add(phoneInput);
			panel.add(joinButton);
			panel.add(cancelButton);
			
			add(panel);
			setSize(250, 270);
			setResizable(false);
			setVisible(true);
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource() == joinButton) {  //고객등록 , 고객리스트등록
				customerList.add(new Customer(nameInput.getText(), phoneInput.getText(), birthInput.getText()));
				CustomerRW crw = new CustomerRW(customerList);
				crw.saveFile();
				setVisible(false);
			}
			else if (e.getSource() == cancelButton) { //취소버튼
				setVisible(false);
			}
		}
	}
	
	class CustomerModify extends CustomerEnroll {
		private String name;
		public CustomerModify() {
			super("고객 변경", "변경", "삭제");
			name = bottom_middle_center_center.getText();
			for(int i=0; i<customerList.size(); i++){
				if(name.equals(customerList.get(i).getName())){
					nameInput.setText(name);
					phoneInput.setText(customerList.get(i).getPhone());
					birthInput.setText(customerList.get(i).getBirth());
					break;
				}
			}
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource() == joinButton) {  //고객등록 , 고객리스트등록
				name = nameInput.getText();
				for(int i=0; i<customerList.size(); i++) {
					if(name.equals(customerList.get(i).getName())) {
						customerList.get(i).setName(name);
						customerList.get(i).setPhone(phoneInput.getText());
						customerList.get(i).setBirth(birthInput.getText());
						break;
					}
				}
				CustomerRW crw = new CustomerRW(customerList);
				crw.saveFile();
				setVisible(false);
			}
			else if (e.getSource() == cancelButton) { //삭제버튼
				name = nameInput.getText();
				for(int i=0; i<customerList.size(); i++) {
					if(name.equals(customerList.get(i).getName())) {
						customerList.remove(i);
						break;
					}
				}
				CustomerRW crw = new CustomerRW(customerList);
				crw.saveFile();
				setVisible(false);
			}
		}
	}
	

}