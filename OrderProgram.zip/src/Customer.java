import java.io.Serializable;


public class Customer implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String phone;
	private String birth;
	
	Customer(String name,String phone, String birth){
		this.name =name;
		this.phone = phone;
		this.birth = birth;
	}
	
	public String getName() {
		return this.name;
	}
	public String getPhone() {
		return this.phone;
	}
	public String getBirth() {
		return this.birth;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
}
