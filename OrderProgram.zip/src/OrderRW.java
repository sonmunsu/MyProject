import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class OrderRW {
	
	private ArrayList<Order> u;
	private String fileName;
    
    public OrderRW(ArrayList<Order> u) {
    	this.u = u;
    }
    
	public OrderRW(String fileName) {
		this.fileName = fileName;
	}
	
	 public void saveFile() {
	        FileOutputStream fout = null;
	        ObjectOutputStream oos = null;
	        
	        try{
	            fout = new FileOutputStream("order.dat");
	            oos = new ObjectOutputStream(fout);
	            
	            oos.writeObject(u);
	            oos.reset();
	            
	            System.out.println("주문 정보가 저장되었습니다");
	            
	        }catch(Exception ex){
	        	ex.printStackTrace();
	        }finally{
	            try{
	                oos.close();
	                fout.close();
	            }catch(IOException ioe){}
	        } // finally
	    } // saveFile() end
    
	 public ArrayList<Order> readFile() {
			FileInputStream fin = null;
			ObjectInputStream ois = null;

			try{
				fin = new FileInputStream(fileName);
				ois = new ObjectInputStream(fin);
				
				u = (ArrayList<Order>)ois.readObject();

				System.out.println("주문 정보를 불러왔습니다");
				
			}catch(Exception ex){
				ex.printStackTrace();
				System.out.println(ex);
			}finally{
				try{
					ois.close();
					fin.close();
				}catch(IOException ioe){}
			} // finally
			
			return u;
		} // readFile() end
	}
