import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class CustomerRW {

	private static ArrayList<Customer> u;
	private String fileName;
	
	public CustomerRW(ArrayList<Customer> u) {
		this.u = u;
	}
	
	public CustomerRW(String fileName) {
		this.fileName = fileName;
	}
	
	 public void saveFile() {
	        FileOutputStream fout = null;
	        ObjectOutputStream oos = null;
	        
	        try{
	            fout = new FileOutputStream("customerlist.dat");
	            oos = new ObjectOutputStream(fout);
	            
	            oos.writeObject(u);
	            oos.reset();
	            
	            System.out.println("고객 데이터가 저장되었습니다");
	            
	        }catch(Exception ex){
	        	ex.printStackTrace();
	        }finally{
	            try{
	                oos.close();
	                fout.close();
	            }catch(IOException ioe){}
	        } // finally
	    } // saveFile() end
	
	public ArrayList<Customer> readFile() {
		FileInputStream fin = null;
		ObjectInputStream ois = null;

		try{
			fin = new FileInputStream(fileName);
			ois = new ObjectInputStream(fin);
			
			u = (ArrayList<Customer>)ois.readObject();

            System.out.println("고객 데이터를 불러왔습니다.");
            
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				ois.close();
				fin.close();
			}catch(IOException ioe){}
		} // finally
		
		return u;
	} // readFile() end
}
