import java.io.Serializable;


public class MainMenu implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String menu_name;
	private int menu_price;

	MainMenu(String menu_name,int menu_price){
		this.menu_name = menu_name;
		this.menu_price = menu_price;
	
	}
	
	public String getMenu_Name() {
		return this.menu_name;
	}
	public int getMenu_Price() {
		return this.menu_price;
	}


}
